
---

## 1. Recipe

- Assembled by lathing 3 Ichor and 1 Noir

# 2. Value

- **Value:** 175 [**Building Credits**](Building%20Credits)