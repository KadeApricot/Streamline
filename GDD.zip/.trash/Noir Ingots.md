
---

## 1. Definition

- A type of [**Ingots**](Game%20Design%20Document/Automation%20Systems/Materials/Tier%201/Ingots.md)

## 2. Recipe

- Made by [**Smelting**](Foundry.md) [**Ichor Ores**](Ichor%20Ores.md)

## 2. Value

- **Value:** 25 [**Building Credits**](Building%20Credits)

## 1. Symbolism

- Anagram of Iron.
- Means black in French.

## 2. Appearance

- Color: Black
- Shading: Dull