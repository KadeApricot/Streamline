
---

## 1. Usage

- Building Credits are used as a cost to build [**Buildings**](Buildings)
