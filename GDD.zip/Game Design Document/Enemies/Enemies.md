
---

## 1. Enemies

- Enemies are entities designed to destroy [Buildings](Buildings)
- Enemies walk with the axes of the [Grid](Grid)