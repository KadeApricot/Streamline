
---

## 1. The Grid

The game board is a discrete 2D grid. All buildings occupy 1x1 or larger integer coordinates.