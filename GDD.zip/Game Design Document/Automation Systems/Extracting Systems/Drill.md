
---

## 1. Definition

- Mine [[Ores]]
