
---

## 1. Definition

- Mines [[Biomass]]
