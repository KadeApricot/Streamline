
---

## 1. Mines

- **Mines (Resource Nodes):**
	- **Properties:** Static map objects. Contains specific raw materials.
	- **Durability:** Medium Health (destructible by enemies).
