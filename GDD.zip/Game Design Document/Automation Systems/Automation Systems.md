
---

## 1. Automation Systems

- [**Mines**](Mines.md)
- [**Storages**](Drill.md)
- [**Belts:**](Item%20Pipes.md)
- [**The Hall**](Hall)
- [**Processing Systems**](Processing%20Systems.md)
