
---

## Recipe

- [[Alloys|Alloying]] 2 [[Biomass]] and 1 [[Electrum Catalyst]] gives 1 [[Liquid Ethanol]]
