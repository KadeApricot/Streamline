
---

## Recipe

- [[Centrifuge|Purifying]] 1  [[Koopa Alloys]] gives 1 [[Electrum Catalyst]]
