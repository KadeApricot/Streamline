
---

## 1. Recipe

- Made by:
	- [[Assembler|Assembling]] 1 [[Koopa Alloys]] and 3 [[Cloa' Ingots]]

## 2. Value

- **Values:** 160 [Building Credits](Building%20Credits)
