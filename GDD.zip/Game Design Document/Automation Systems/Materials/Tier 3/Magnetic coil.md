
- Assembled by:
	- Lathing 1 [[Shaft]] and 6 Sprockets
	- <=> 28 [[Cloa' Ingots]]

## 2. Value

- **Value:** 980
