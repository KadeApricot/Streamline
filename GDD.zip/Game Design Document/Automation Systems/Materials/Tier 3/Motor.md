
---

## 1. Recipe

- Made by:
	- Mixing 1 [[Whisk]], 3 Sprockets and 2 [[Cylindrome]]
	- <=> 3 [[Electrum Ingots]] and 21 [[Cloa' Ingots]]

## 2. Value

- **Value:** 895
