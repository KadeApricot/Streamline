
---

## 1. Definition

- A type of [**Ingots**](Game%20Design%20Document/Automation%20Systems/Materials/Tier%201/Ingots.md)

## 2. Recipe

- Made by [**Smelting**](Foundry.md) [[Electrum Ores]]

## 2. Value

- **Value:** 40 **[[Building Credits]]**

## 4. Visuals

### Appearance

- Color: Gold
- Shading: Shiny

### Symbolism

- Means ethereal fluid that flows in the veins of Greek gods.
