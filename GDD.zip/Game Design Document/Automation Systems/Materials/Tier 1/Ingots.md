
---

## 1. Recipe

- Ingots are acquired by [**Smelting**](Foundry) [**Ores**](ores)
