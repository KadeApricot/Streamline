
---

## 1. Definition

- A type of [**Ingots**](Game%20Design%20Document/Automation%20Systems/Materials/Tier%201/Ingots.md)

## 2. Recipe

- Made by [**Smelting**](Foundry.md) [[Game Design Document/Automation Systems/Materials/Tier 0/Cloa' Ores]]

## 2. Value

- **Value:** 20 **[[Building Credits]]**

## 4. Visuals
### Appearance

- Color: Black grey
- Shading: Dull

### Symbolism

- Means black in French