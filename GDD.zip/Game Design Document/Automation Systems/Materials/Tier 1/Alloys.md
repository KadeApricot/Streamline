
---

## 1. Definition

- Alloying is the processing of combining [**Ingots**](Ingots) by [**Smelting**](Foundry) them together or extracting [**Ingots**](Ingots) from another type of [**Ingots**](Ingots).

## 2. Alloys

- [[ Alloys]]
- [[Koopa Alloys]]