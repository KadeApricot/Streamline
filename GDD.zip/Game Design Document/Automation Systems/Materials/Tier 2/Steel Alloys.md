
---

## Recipe

- Made by [[Foundry|Alloying]] 1 [[Carbo Fiber]] and 1 [[Cloa' Ingots]]
