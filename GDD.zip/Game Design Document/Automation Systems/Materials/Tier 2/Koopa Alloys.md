
---

## 1. Recipe

- [**Purifying**](Centrifuge) 2 [**Electrum Ingots**](Electrum%20Ingots.md) gives 1 **Koopa Alloys**
