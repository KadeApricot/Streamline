---
aliases:
  - \Sora Alloys
---

---

## 1. Definition

- A type of [**Alloys**](Alloys)

## 2. Recipe

- Made by [[Foundry|Alloying]] 1 [**Electrum Ingots**] and 1 [[Cloa' Ingots]]

## 3. Value

- **Values:** 80 [**Building Credits**](Building%20Credits)

## 4. Visuals

### Appearance

- Color: Red
- Shading: Glitter
