
---

## 1. Recipe

- Assembled by:
	- [[Casting Table|Casting]] 4 [[Cloa' Ingots]]
		- <=> 4 [[Cloa' Ores]]
		- Output 2 Sprockets

## 2. Value

- **Value:** 110 [**Building Credits**](Building%20Credits)
