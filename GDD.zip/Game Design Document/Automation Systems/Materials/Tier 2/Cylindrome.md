
---

## 1. Recipe

- Assembled by:
	- [[Loom|Looming]] 2 [[Electrum Ingots]]
	- <=> 2 [[Electrum Ores]]

## 2. Value

- **Value:** 110 [Building Credits](Building%20Credits)
