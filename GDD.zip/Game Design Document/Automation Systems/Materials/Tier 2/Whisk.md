
---

## ## 1. Recipe

- Assembled by:
	- [[Plasma Cutter|Plasma Cutting]] 4 [[Cloa' Ingots]]
	- <=> 4 [[Cloa' Ores]]

## 2. Value

- **Value:** 110 [**Building Credits**](Building%20Credits)
