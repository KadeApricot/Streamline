- Made by:
	- Mixing 1 [[Whisk]], 1 [[Plating]], 4 [[Sprocket]]
	- <=> 6 [[Electrum Ingots]] and 17 [[Cloa' Ingots]]

## 2. Values

- **Values:** 925
