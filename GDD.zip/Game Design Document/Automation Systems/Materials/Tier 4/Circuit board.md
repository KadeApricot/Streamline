
- Made by
	- lathing 5 [[Shaft]], 1 [[Plating]]
	- <=> 3 Electrums 20 [[Cloa' Ingots]]

## 2. Value

- **Value:** 880
