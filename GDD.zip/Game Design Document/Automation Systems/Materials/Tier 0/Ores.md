
---

## 1. Processing

- Ores can be [**Smelt**](Foundry) into [**Ingots**](Ingots.md)

## 2. Acquisition

- Ores are collected by using the [**Drill**](Drill.md)
