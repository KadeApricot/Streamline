
---

## 1. Definition

- [[Cloa' Ores]] is a type of [**Ores**](Ores)

## 2. Processing

- Smelting 1 [[Cloa' Ores]] gives 1 [[Cloa' Ingots]]

## 3. Value

- **Value:** 10 [**Building Credits**](Building%20Credits)

## 4. Visuals

### Symbolism

- Anagram of Iron.
- Means black in French.
- Inspired by coal

### Appearance

- Color: Black
- Shading: Dull
