## 1. Recipe

- [**Purifying**](Centrifuge) 1 [[Cloa' Ores]] gives 3 [[Cloa' Clumps]]

## 2. Processing

- [**Smelting**](Foundry) 1 [[Cloa' Clumps]] gives 1 [[Cloa' Ingots]]

## 3. Value

- **Value:** 5 [**Building Credits**](Building%20Credits)
