
---

## 1. Definition

- Electrum Ores is a type of [**Ores**](Ores).

## 2. Processing

- Smelting 1 Electrum Ores gives 1 [[Electrum Ingots]]

## 3. Value

- **Value:** 20 [**Building Credits**](Building%20Credits)

## 4. Visuals

### Symbolism

- Means ethereal fluid that flows in the veins of Greek gods.

### Appearance

- Color: Gold
- Shading: Shiny
