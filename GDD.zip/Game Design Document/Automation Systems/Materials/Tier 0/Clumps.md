
---

## 1. Processing

- Clumps can be [**Smelt**](Foundry) into [**Ingots**](Ingots.md), just like [**Ores**](Ores)

## 2. Recipe

- Clumps are made by purifying [**Ores**](Ores) with the [**Centrifuge**](Centrifuge)
