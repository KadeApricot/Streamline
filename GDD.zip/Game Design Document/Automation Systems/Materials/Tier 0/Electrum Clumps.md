
---

## 1. Recipe

- [**Purifying**](Centrifuge) 1 [**Electrum Ores**](Electrum%20Ores) gives 2 **Electrum Clumps**

## 2. Processing

- [**Smelting**](Foundry) 1 Electrum Clumps** gives 1 [**Electrum Ingots**](Electrum%20Ingots)

## 3. Value

- **Value:** 10 [**Building Credits**](Building%20Credits)
