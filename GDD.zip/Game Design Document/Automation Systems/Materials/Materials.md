---
color: ""
sticker: lucide//package
---

---

## 1. Definition

- Materials can be collected and traded for [**Building Credits**](Building%20Credits.md) *or* assembled to craft [[Usaables]]
