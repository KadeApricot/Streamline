
---

## 1. Hall

- **The Hall (Core):**
    - **Function:** The central hub. Store processed components or material.
    - **Win/Loss:** If the Hall is destroyed, **Game Over**.
    - **Durability:** Very High Health.