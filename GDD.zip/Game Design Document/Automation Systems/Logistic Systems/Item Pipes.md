
---

- **Belts (Logistics):**
	- **Function:** Moves items/towers from an Input side to an Output side (Orthogonal).
	- **Durability:** Medium Health.
	- **Placement Rule:** Can bridge small gaps but primarily ground-based.
