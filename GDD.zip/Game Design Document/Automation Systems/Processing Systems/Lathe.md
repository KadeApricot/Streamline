---
sticker: lucide//ruler
---

---

## 1. Definition

- A lathe rolls an object around an axis and carve parts out of it
- 