---
sticker: lucide//package-plus
---

---

## 1. Definition

- An assembler is a type of [**Buildings**](Buildings)
- An assembler mixes multiple small components together to form a bigger component or a tool.
- An assembler has 3 input slots