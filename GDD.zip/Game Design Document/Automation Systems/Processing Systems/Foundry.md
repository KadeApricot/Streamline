---
sticker: lucide//flame
---

---

## 1. Foundries

- A foundry is a type of [**Buildings**](Buildings)
- A foundry smelts [**Raw Ores**](Ores.md) into [**Ingots**](Game%20Design%20Document/Automation%20Systems/Materials/Tier%201/Ingots.md)
- A foundry can do alloying
- It can have 3 slots of input but just one slot of output