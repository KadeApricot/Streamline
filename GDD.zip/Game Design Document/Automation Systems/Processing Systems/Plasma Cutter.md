---
sticker: lucide//pencil
---

---

## 1. Definition

- A lathe is a type of [**Buildings**](Buildings)
- A lathe turns processed [**Materials**](Materials) into more high-level Materials by rotating objects and sculping them.
- A lathe has two input slot and one output slot.