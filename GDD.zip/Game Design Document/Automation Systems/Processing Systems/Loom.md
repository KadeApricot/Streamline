---
sticker: lucide//bar-chart
---

---

## 1. Definition

- Extrudes [**Ingots**](Ingots) or other [**Materials**](Materials) into a long thin cylinderal 