---
sticker: lucide//scissors
---

---

## 1. Definition

- Processing Systems transform [**Materials**](Materials).
