---
sticker: lucide//tornado
---

---

# 1. Definition

- A centrifuge crushes ores into multiple clumps, which is faster to [**Smelt**](Foundry) and generates the same amount of ingots as ores
- A centrifuge also purify ingots to extract new materials like [**Koopa**](Koopa%20Alloys.md)